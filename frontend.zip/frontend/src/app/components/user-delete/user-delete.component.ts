import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-user-delete',
  templateUrl: './user-delete.component.html',
  styleUrls: ['./user-delete.component.css']
})
export class UserDeleteComponent implements OnInit {
  id: string;

  constructor(
    private route: ActivatedRoute,
    private userService: UserService,
    private router: Router
  ) {
    this.id = this.route.snapshot.paramMap.get('id')!;
  }

  ngOnInit(): void {
    this.deleteUser();
  }

  deleteUser() {
    this.userService.deleteUser(this.id).subscribe(
      response => {
        console.log('User deleted successfully!', response);
        this.router.navigate(['/users']);
      },
      error => {
        console.error('Error deleting user', error);
      }
    );
  }
}
