import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-user-update',
  templateUrl: './user-update.component.html',
  styleUrls: ['./user-update.component.css']
})
export class UserUpdateComponent implements OnInit {
  user = {
    name: '',
    email: '',
    address: ''
  };
  id: string;

  constructor(
    private route: ActivatedRoute,
    private userService: UserService,
    private router: Router
  ) {
    this.id = this.route.snapshot.paramMap.get('id')!;
  }

  ngOnInit(): void {
    this.userService.getAllUsers().subscribe(
      response => {
        const foundUser = response.find((u: any) => u._id === this.id);
        if (foundUser) {
          this.user = foundUser;
        }
      },
      error => {
        console.error('Error fetching user', error);
      }
    );
  }

  updateUser() {
    this.userService.updateUser(this.id, this.user).subscribe(
      response => {
        console.log('User updated successfully!', response);
        this.router.navigate(['/users']);
      },
      error => {
        console.error('Error updating user', error);
      }
    );
  }
}
